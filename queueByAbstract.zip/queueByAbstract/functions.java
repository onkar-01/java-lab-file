public abstract class functions{
    public abstract void Endque(int val);
    public abstract void Deque();
    public abstract boolean isFull();
    public abstract boolean isEmpty();

}