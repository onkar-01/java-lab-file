class linearQueue extends functions{
    
}